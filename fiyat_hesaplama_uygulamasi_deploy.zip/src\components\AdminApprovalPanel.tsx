'use client';

import { useState, useEffect } from 'react';
import { Customer } from '@/lib/types';
import { Button } from './ui/Button';
import { Input } from './ui/Input';
import { Loader2, CheckCircle, XCircle, AlertTriangle } from 'lucide-react';

export function AdminApprovalPanel() {
    const [leads, setLeads] = useState<Customer[]>([]);
    const [loading, setLoading] = useState(true);
    const [processing, setProcessing] = useState<string | null>(null);

    // Modal state
    const [modalOpen, setModalOpen] = useState(false);
    const [modalAction, setModalAction] = useState<'approve' | 'reject' | 'guarantor'>('approve');
    const [selectedLead, setSelectedLead] = useState<Customer | null>(null);
    const [formData, setFormData] = useState({ kredi_limiti: '', admin_notu: '' });

    useEffect(() => {
        fetchPendingApprovals();
    }, []);

    const fetchPendingApprovals = async () => {
        setLoading(true);
        try {
            const res = await fetch('/api/admin/pending-approvals');
            const json = await res.json();

            if (res.ok) {
                setLeads(json.leads || []);
            }
        } catch (error) {
            console.error('Failed to fetch pending approvals', error);
        } finally {
            setLoading(false);
        }
    };

    const openModal = (lead: Customer, action: 'approve' | 'reject' | 'guarantor') => {
        setSelectedLead(lead);
        setModalAction(action);
        setFormData({ kredi_limiti: '', admin_notu: '' });
        setModalOpen(true);
    };

    const closeModal = () => {
        setModalOpen(false);
        setSelectedLead(null);
        setFormData({ kredi_limiti: '', admin_notu: '' });
    };

    const handleApprove = async () => {
        if (!selectedLead || !formData.kredi_limiti) {
            alert('Lütfen kredi limitini girin');
            return;
        }

        setProcessing(selectedLead.id);
        try {
            const res = await fetch('/api/admin/approve', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    customerId: selectedLead.id,
                    kredi_limiti: formData.kredi_limiti,
                    admin_notu: formData.admin_notu
                })
            });

            if (res.ok) {
                alert('Başvuru onaylandı!');
                fetchPendingApprovals();
                closeModal();
            } else {
                alert('Onaylama başarısız oldu.');
            }
        } catch (error) {
            console.error('Approve error:', error);
            alert('Bir hata oluştu.');
        } finally {
            setProcessing(null);
        }
    };

    const handleRejectOrGuarantor = async () => {
        if (!selectedLead) return;

        setProcessing(selectedLead.id);
        try {
            const res = await fetch('/api/admin/reject', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    customerId: selectedLead.id,
                    action: modalAction === 'reject' ? 'reject' : 'request_guarantor',
                    reason: formData.admin_notu
                })
            });

            if (res.ok) {
                alert(modalAction === 'reject' ? 'Başvuru reddedildi.' : 'Kefil istendi.');
                fetchPendingApprovals();
                closeModal();
            } else {
                alert('İşlem başarısız oldu.');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Bir hata oluştu.');
        } finally {
            setProcessing(null);
        }
    };

    return (
        <>
            <div className="bg-white rounded-lg shadow p-6">
                <h2 className="text-xl font-bold mb-4">Onay Bekleyen Başvurular</h2>

                {loading ? (
                    <div className="flex justify-center py-8">
                        <Loader2 className="w-6 h-6 animate-spin text-indigo-600" />
                    </div>
                ) : leads.length === 0 ? (
                    <p className="text-gray-500 text-center py-8">Onay bekleyen başvuru yok.</p>
                ) : (
                    <div className="space-y-4">
                        {leads.map((lead) => (
                            <div key={lead.id} className="border border-gray-200 rounded-lg p-4">
                                <div className="flex justify-between items-start mb-3">
                                    <div>
                                        <h3 className="font-semibold text-gray-900">{lead.ad_soyad}</h3>
                                        <p className="text-sm text-gray-600">{lead.telefon}</p>
                                        <p className="text-xs text-gray-500 mt-1">Sahip: {lead.sahip}</p>
                                    </div>
                                    <span className="text-xs text-gray-500">
                                        {new Date(lead.created_at).toLocaleDateString('tr-TR')}
                                    </span>
                                </div>

                                <div className="flex flex-wrap gap-2">
                                    <Button
                                        size="sm"
                                        onClick={() => openModal(lead, 'approve')}
                                        isLoading={processing === lead.id}
                                        className="flex items-center gap-1"
                                    >
                                        <CheckCircle className="w-4 h-4" />
                                        Onayla
                                    </Button>
                                    <Button
                                        size="sm"
                                        variant="outline"
                                        onClick={() => openModal(lead, 'guarantor')}
                                        isLoading={processing === lead.id}
                                        className="flex items-center gap-1"
                                    >
                                        <AlertTriangle className="w-4 h-4" />
                                        Kefil İste
                                    </Button>
                                    <Button
                                        size="sm"
                                        variant="secondary"
                                        onClick={() => openModal(lead, 'reject')}
                                        isLoading={processing === lead.id}
                                        className="flex items-center gap-1"
                                    >
                                        <XCircle className="w-4 h-4" />
                                        Reddet
                                    </Button>
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>

            {/* Modal */}
            {modalOpen && selectedLead && (
                <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
                    <div className="bg-white rounded-lg shadow-xl max-w-md w-full p-6">
                        <h3 className="text-lg font-bold mb-4">
                            {modalAction === 'approve' && 'Başvuruyu Onayla'}
                            {modalAction === 'reject' && 'Başvuruyu Reddet'}
                            {modalAction === 'guarantor' && 'Kefil İste'}
                        </h3>

                        <p className="text-sm text-gray-600 mb-4">
                            <strong>{selectedLead.ad_soyad}</strong> için işlemi tamamlayın.
                        </p>

                        {modalAction === 'approve' && (
                            <Input
                                label="Kredi Limiti *"
                                type="text"
                                placeholder="Örn: 50000 TL"
                                value={formData.kredi_limiti}
                                onChange={(e) => setFormData({ ...formData, kredi_limiti: e.target.value })}
                                className="mb-4"
                            />
                        )}

                        <div className="mb-4">
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                                Not {modalAction === 'approve' ? '(Opsiyonel)' : '(Zorunlu)'}
                            </label>
                            <textarea
                                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 min-h-[80px]"
                                placeholder={modalAction === 'reject' ? 'Red sebebini yazın' : 'Notunuzu yazın'}
                                value={formData.admin_notu}
                                onChange={(e) => setFormData({ ...formData, admin_notu: e.target.value })}
                            />
                        </div>

                        <div className="flex gap-2 justify-end">
                            <Button variant="outline" onClick={closeModal}>İptal</Button>
                            <Button
                                onClick={modalAction === 'approve' ? handleApprove : handleRejectOrGuarantor}
                                isLoading={processing === selectedLead.id}
                            >
                                Onayla
                            </Button>
                        </div>
                    </div>
                </div>
            )}
        </>
    );
}
