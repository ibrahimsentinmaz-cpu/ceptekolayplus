'use client';

import { useState } from 'react';
import { Customer, LeadStatus } from '@/lib/types';
import { Button } from './ui/Button';
import { Input } from './ui/Input';
import { Select } from './ui/Select';
import { Loader2 } from 'lucide-react';

interface CustomerCardProps {
    initialData: Customer;
    onSave?: (updated: Customer) => void;
}

const STATUS_OPTIONS: { value: LeadStatus; label: string }[] = [
    { value: 'Yeni', label: 'Yeni' },
    { value: 'Aranacak', label: 'Aranacak' },
    { value: 'Ulaşılamadı', label: 'Ulaşılamadı' },
    { value: 'Meşgul/Hattı kapalı', label: 'Meşgul/Hattı kapalı' },
    { value: 'Yanlış numara', label: 'Yanlış numara' },
    { value: 'Daha sonra aranmak istiyor', label: 'Daha sonra aranmak istiyor' },
    { value: 'WhatsApp’tan bilgi istiyor', label: 'WhatsApp’tan bilgi istiyor' },
    { value: 'E-Devlet paylaşmak istemedi', label: 'E-Devlet paylaşmak istemedi' },
    { value: 'Başvuru alındı', label: 'Başvuru alındı' },
    { value: 'Mağazaya davet edildi', label: 'Mağazaya davet edildi' },
    { value: 'Kefil bekleniyor', label: 'Kefil bekleniyor' },
    { value: 'Eksik evrak bekleniyor', label: 'Eksik evrak bekleniyor' },
    { value: 'Onaya gönderildi', label: 'Onaya gönderildi' },
    { value: 'Teslim edildi', label: 'Teslim edildi' },
    { value: 'Satış yapıldı/Tamamlandı', label: 'Satış yapıldı/Tamamlandı' },
    { value: 'Reddetti', label: 'Reddetti' },
    { value: 'Uygun değil', label: 'Uygun değil' },
    { value: 'İptal/Vazgeçti', label: 'İptal/Vazgeçti' },
];

export function CustomerCard({ initialData, onSave }: CustomerCardProps) {
    const [data, setData] = useState<Customer>(initialData);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const handleChange = (field: keyof Customer, value: any) => {
        setData((prev) => ({ ...prev, [field]: value }));
    };

    const handleSave = async () => {
        setError(null);
        setLoading(true);

        // Validation
        if (!data.ad_soyad || !data.telefon || !data.tc_kimlik) {
            setError('Ad Soyad, Telefon ve TC Kimlik zorunludur.');
            setLoading(false);
            return;
        }

        if (data.durum === 'Daha sonra aranmak istiyor' && !data.sonraki_arama_zamani) {
            setError('"Daha sonra aranmak istiyor" durumu için Sonraki Arama Zamanı zorunludur.');
            setLoading(false);
            return;
        }

        // Validate delivery fields when marking as delivered
        if ((data.durum === 'Teslim edildi' || data.durum === 'Satış yapıldı/Tamamlandı') && (!data.urun_seri_no || !data.urun_imei)) {
            setError('Teslimat tamamlamak için Ürün Seri No ve IMEI zorunludur.');
            setLoading(false);
            return;
        }

        try {
            // Auto-fill delivery tracking if marking as delivered
            const updateData = { ...data };
            if ((data.durum === 'Teslim edildi' || data.durum === 'Satış yapıldı/Tamamlandı') && !data.teslim_tarihi) {
                updateData.teslim_tarihi = new Date().toISOString();
                updateData.teslim_eden = data.sahip || 'Unknown';
            }

            const res = await fetch(`/api/leads/${data.id}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(updateData),
            });

            if (!res.ok) throw new Error('Failed to update');

            const json = await res.json();
            setData(json.lead); // Update local state with server response
            if (onSave) onSave(json.lead);
            alert('Kaydedildi!');
        } catch (err) {
            setError('Kaydedilemedi. Lütfen tekrar deneyin.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="bg-white shadow rounded-lg p-6 max-w-2xl mx-auto border border-gray-200">
            <h2 className="text-xl font-bold mb-4 text-gray-800 border-b pb-2">Müşteri Kartı</h2>

            {error && (
                <div className="mb-4 bg-red-50 text-red-700 p-3 rounded-md text-sm">
                    {error}
                </div>
            )}

            <div className="space-y-4">
                {/* Mandatory Fields */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Input
                        label="Ad Soyad *"
                        value={data.ad_soyad || ''}
                        onChange={(e) => handleChange('ad_soyad', e.target.value)}
                    />
                    <Input
                        label="Telefon *"
                        value={data.telefon || ''}
                        onChange={(e) => handleChange('telefon', e.target.value)}
                    />
                    <Input
                        label="TC Kimlik *"
                        value={data.tc_kimlik || ''}
                        onChange={(e) => handleChange('tc_kimlik', e.target.value)}
                        maxLength={11}
                    />
                    <Input
                        label="Şehir"
                        value={data.sehir || ''}
                        onChange={(e) => handleChange('sehir', e.target.value)}
                    />
                </div>

                {/* Status Section */}
                <div className="bg-gray-50 p-4 rounded-md border border-gray-100">
                    <label className="block text-sm font-medium text-gray-700 mb-2">Durum ve Takip</label>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <Select
                            label="Durum"
                            value={data.durum}
                            onChange={(e) => handleChange('durum', e.target.value)}
                            options={STATUS_OPTIONS}
                        />
                        <Input
                            type="datetime-local"
                            label="Sonraki Arama Zamanı"
                            value={data.sonraki_arama_zamani || ''}
                            onChange={(e) => handleChange('sonraki_arama_zamani', e.target.value)}
                        />
                    </div>
                </div>

                {/* Details */}
                <div className="grid grid-cols-1 gap-4">
                    <Input
                        label="E-Devlet Şifre"
                        value={data.e_devlet_sifre || ''}
                        onChange={(e) => handleChange('e_devlet_sifre', e.target.value)}
                    />
                    <div className="w-full">
                        <label className="block text-sm font-medium text-gray-700 mb-1">Kısa Not</label>
                        <input
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                            value={data.arama_not_kisa || ''}
                            onChange={(e) => handleChange('arama_not_kisa', e.target.value)}
                        />
                    </div>
                    <div className="w-full">
                        <label className="block text-sm font-medium text-gray-700 mb-1">Uzun Açıklama</label>
                        <textarea
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 min-h-[100px]"
                            value={data.aciklama_uzun || ''}
                            onChange={(e) => handleChange('aciklama_uzun', e.target.value)}
                        />
                    </div>
                </div>

                {/* Delivery Tracking Section - Show only if approved or invited */}
                {(data.onay_durumu === 'Onaylandı' || data.durum === 'Mağazaya davet edildi' || data.durum === 'Onaya gönderildi') && (
                    <div className="border-t pt-4 mt-4">
                        <h3 className="text-sm font-semibold mb-3 text-gray-700 flex items-center gap-2">
                            📦 Ürün Teslimat Bilgileri
                            {data.onay_durumu === 'Onaylandı' && data.kredi_limiti && (
                                <span className="text-xs bg-green-50 text-green-700 px-2 py-1 rounded-full">
                                    Onaylı Limit: {data.kredi_limiti}
                                </span>
                            )}
                        </h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <Input
                                label="Ürün Seri No"
                                value={data.urun_seri_no || ''}
                                onChange={(e) => handleChange('urun_seri_no', e.target.value)}
                                placeholder="Örn: ABC123456789"
                            />
                            <Input
                                label="IMEI Numarası"
                                value={data.urun_imei || ''}
                                onChange={(e) => handleChange('urun_imei', e.target.value)}
                                placeholder="Örn: 123456789012345"
                                maxLength={15}
                            />
                        </div>
                        <div className="mt-3 text-xs text-gray-500 bg-blue-50 p-3 rounded-lg">
                            💡 <strong>Bilgi:</strong> Ürün seri numarası ve IMEI'yi girdikten sonra durumu "Teslim edildi" yaparak teslimatı tamamlayabilirsiniz.
                        </div>
                    </div>
                )}

                {/* Footer Actions */}
                <div className="pt-4 flex justify-end">
                    <Button onClick={handleSave} isLoading={loading} className="w-full md:w-auto">
                        Değişiklikleri Kaydet
                    </Button>
                </div>
            </div>
        </div>
    );
}
